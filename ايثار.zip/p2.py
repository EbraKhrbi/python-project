 
e=int (input("Enter number 1:"))
j=int (input("Enter number 2:"))

c=e/j
if e%j==0:
    print(True)
elif e%j==1:
    print(False)