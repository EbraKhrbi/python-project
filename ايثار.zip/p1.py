a=[56,90,87,50,46,23,89]

max=a[0]
min=a[0]
r=0

for i in a:
    if i > max:
        max=i
    if i < min:
        min=i

print("max =",max,"min =",min)
