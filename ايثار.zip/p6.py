a=[1,2,3,3,3,3,4,5]
print(set(a))