op=int(input("Enter number"))
ax=1
for i in range(1,op+1):
    ax = ax*i
    print(ax)