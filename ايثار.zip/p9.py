class rectangle:
    def __init__(self,length,width):
        self.length=length
        self.width=width
    def area_rectangle(self,length,width):
        area=length*width
        return area
    def  mference_rectangle(self,length,width):
         mference1=2*(length+width )
         return mference1

a=int(input("Enter length:"))
b=int(input("Enter width:"))
rectangle1=rectangle(a,b)
print(rectangle1.area_rectangle(a,b))
print(rectangle1.mference_rectangle(a,b))
