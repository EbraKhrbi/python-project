a=int(input("Enter number:"))
group=[1,5,8,3,3]
if a in group:
    print(True)
else:
    print(False)