p=3.1415

class circle:

    def __init__(self,p,radius):
        self.p=p
        self.radius=radius
    def circle_area(self,p,radius):
        area=p*radius*radius
        return area
    def circle_mference(self,p,radius):
        mference=2*p*radius
        return mference
r=float(input("Enter radius"))
circle1=circle(p,r)
print(circle1.circle_area(p, r))
print(circle1.circle_mference(p, r))