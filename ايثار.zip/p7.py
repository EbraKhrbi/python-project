a=input("Enter:")
 
e=""
b=len(a)
for i in a:
    e+=a[b-1]
    b=b-1
d=e
print(d)
if d==a:
    print(True)
else:
    print(False)